'use client'

import db from '@/db';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';


interface editProps{
    params : {
        id: string;
    }
}


interface formType{
    name : string,
    title : string,
    content : string
}

export default async function Edit(props:editProps){
    console.log(props.params.id)
    

    // 'update 테이블명 set 필드=변경값, 필드=변경값, 필드=변경값 where id = 변경할 아이디'
    // ('update brd.board set title=?, content=? where id=?',[title,content,id])
    const params = useParams()
    const [formData, setFormData] = useState<formType>({
        name : '',
        title : '',
        content : ''
    })
    const changeEvent = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({...formData, [e.target.name] : e.target.value})
        console.log(formData)
    }
    const submitEvent = async (e: React.FormEvent<HTMLFormElement>)=>{
        e.preventDefault()
        try{
            const res = await fetch(`/api/edit/${params.id}`,{
                method : 'POST',
                headers : {
                    'Content-Type' : 'application/json'
                },
                body : JSON.stringify(formData)
            })
            if(res.ok){
                const data = await res.json()
                console.log(data.message)
                // alert("정상적으로 등록 하였습니다.")
                window.location.href = '/'
            }else{
                const errorData = await res.json()
                console.log(errorData.error)
            }
        }catch(error){
            console.log(error)
        }
    }
    return(
        <>
                <form method="post" onSubmit={submitEvent}>
                    <div className="max-w-7xl mx-auto p-6 border">
                        <div className="flex gap-x-2 pb-2 items-center">   
                            <p>작성자 : </p>
                            <input type="text" name="name" onChange={changeEvent} className="shadow text-gray-700 text-sm border" />
                        </div>
                        <div className="flex gap-x-2 pb-2 items-center">
                            <p>제목 : </p>
                            <input type="text" name="title" onChange={changeEvent} className="shadow text-gray-700 text-sm border" />
                        </div>
                        <div className="">
                            <p className='pb-2'>내용 :</p>
                            <textarea name="content" onChange={changeEvent} className="shadow text-gray-700 text-sm border w-[98%]"></textarea>
                        </div>
                        <div className="flex justify-end gap-x-3 pr-5 pt-10">
                            <Link href="/" className='bg-red-500 inline-block text-white px-4 py-2 rounded shadow-md hover:bg-red-600 focus:outline-none '>취소</Link>
                            <button className='bg-blue-500 text-white px-4 py-2 rounded shadow-md hover:bg-blue-600 focus:outline-none '>등록</button>
                        </div>
                    </div>
                </form>
        </>
    )
}

